# Bot de Discord Bus Simulator 95D

El bot responde en español a estos comandos con prefijo `!`:

- `!ruta`
- `!rutas`
- `!consejos`
- `!unidades`
- `!incidentes`
- `!info`
- `!reglas`
- `!sesion`
- `!reporte`
- `!anuncio`
- `!evento`
- `!advertir`
- `!avisos`
- `!limpiar`
- `!expulsar`
- `!ban`
- `!desban`
- `!silenciar`
- `!encuesta`
- `!servidor`
- `!staff`
- `!ayuda`

## Publicar un anuncio o evento

Escribe `!anuncio #canal mensaje` o `!evento #canal mensaje` en un canal del servidor. También puedes usar el ID del canal en lugar de mencionarlo.

Solo pueden publicar miembros con permiso de **Administrador** o con el rol `Administrador`. El anuncio o evento se publica como embed en el canal indicado. El bot necesita permiso para ver y enviar mensajes en ese canal.

## Moderación y administración

- `!advertir @usuario motivo` — registra una advertencia.
- `!avisos @usuario` — consulta sus advertencias.
- `!limpiar cantidad` — elimina de 1 a 100 mensajes recientes.
- `!expulsar @usuario motivo` — expulsa a un miembro.
- `!ban @usuario motivo` — bloquea a un miembro.
- `!desban ID_DEL_USUARIO` — retira un bloqueo.
- `!silenciar @usuario minutos` — limita a un miembro hasta por 28 días.
- `!encuesta pregunta` — publica una encuesta con reacciones ✅ y ❌.
- `!servidor` — muestra información del servidor.
- `!staff` — muestra los miembros con el rol `Administrador`.

Los comandos de moderación requieren permiso de **Administrador** o el rol `Administrador`. Además, `!limpiar` requiere **Gestionar mensajes**. Los avisos se guardan en memoria y se borran si el bot se reinicia.

## Preguntar al bot

Menciona al bot y pregunta de forma natural sobre rutas, sesiones y horarios, reglas, consejos, autobuses, incidentes, reportes o la comunidad. Por ejemplo: `@Bot ¿cómo hago una ruta?`. Si no reconoce el tema, avisará al rol de moderadores y dirá que esperará su respuesta; si el rol no está disponible, te lo indicará. También puedes usar `!ayuda`.

## Configuración

1. Si el token anterior se compartió en un chat, restablécelo en Discord Developer Portal → Applications → tu aplicación → Bot → Reset Token.
2. En Replit, guarda el token nuevo como el secreto `DISCORD_TOKEN`. No lo escribas en el código ni en el chat.
3. En Discord Developer Portal → Applications → tu aplicación → Bot, activa **Message Content Intent** y **Server Members Intent** (este último se usa para `!staff`).
4. Invita el bot al servidor con el scope `bot` y los permisos **View Channels**, **Read Message History**, **Send Messages**, **Embed Links**, **Add Reactions**, **Manage Messages**, **Kick Members**, **Ban Members** y **Moderate Members**.
5. Inicia el workflow **Discord Bot 95D** en Replit.

El bot usa la ruta, reglas y horario `22:00 hrs (CDMX)` indicados para el servidor. El número proporcionado se muestra como ID del servidor, no como IP.

## Desarrollo

- `pnpm --filter @workspace/scripts run discord-bot` — iniciar el bot
- `pnpm --filter @workspace/scripts run typecheck` — verificar TypeScript

