#!/bin/sh
set -eu

pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/scripts run build
