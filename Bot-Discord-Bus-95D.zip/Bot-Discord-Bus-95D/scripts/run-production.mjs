import { spawn } from "node:child_process";
import process from "node:process";

if (!process.env.DISCORD_TOKEN) {
  throw new Error("DISCORD_TOKEN is required to start the Discord bot.");
}

const services = [
  {
    name: "API Server",
    args: ["--enable-source-maps", "artifacts/api-server/dist/index.mjs"],
  },
  {
    name: "Discord Bot",
    args: ["--enable-source-maps", "scripts/dist/bus-95d-bot.js"],
  },
];

const children = new Map();
const restartTimers = new Map();
let shuttingDown = false;

function scheduleRestart(service, reason) {
  if (shuttingDown || restartTimers.has(service.name)) {
    return;
  }

  console.error(
    `${service.name} stopped (${reason}); restarting in 5 seconds.`,
  );

  const timer = setTimeout(() => {
    restartTimers.delete(service.name);
    startService(service);
  }, 5_000);

  restartTimers.set(service.name, timer);
}

function startService(service) {
  if (shuttingDown) {
    return;
  }

  console.info(`Starting ${service.name}.`);

  const child = spawn(process.execPath, service.args, {
    env: process.env,
    stdio: "inherit",
  });

  children.set(service.name, child);

  child.on("error", (error) => {
    console.error(`Could not start ${service.name}.`, error);
    scheduleRestart(service, "start error");
  });

  child.on("exit", (code, signal) => {
    if (children.get(service.name) === child) {
      children.delete(service.name);
    }

    if (!shuttingDown) {
      scheduleRestart(
        service,
        signal ? `signal ${signal}` : `exit code ${code ?? "unknown"}`,
      );
    }
  });
}

function shutdown(signal) {
  if (shuttingDown) {
    return;
  }

  shuttingDown = true;
  console.info(`Received ${signal}; stopping child services.`);

  for (const timer of restartTimers.values()) {
    clearTimeout(timer);
  }
  restartTimers.clear();

  for (const child of children.values()) {
    if (child.exitCode === null) {
      child.kill("SIGTERM");
    }
  }

  const forceKillTimer = setTimeout(() => {
    for (const child of children.values()) {
      if (child.exitCode === null) {
        child.kill("SIGKILL");
      }
    }
  }, 10_000);
  forceKillTimer.unref();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

for (const service of services) {
  startService(service);
}
