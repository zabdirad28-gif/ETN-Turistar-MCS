import {
  ActivityType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  PermissionFlagsBits,
} from "discord.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  throw new Error(
    "Missing DISCORD_TOKEN. Add the bot token in Replit Secrets before starting the bot.",
  );
}

const PREFIX = "!";
const SESSION_TIME = "22:00 hrs (CDMX)";
const SERVER_ID = "1553134147290136578";
const MODERATOR_ROLE_ID = "1553394921665208340";
const STAFF_ROLE = "Administrador";
const ADMIN_COMMANDS = new Set([
  "advertir",
  "avisos",
  "limpiar",
  "expulsar",
  "ban",
  "desban",
  "silenciar",
  "anuncio",
  "evento",
  "encuesta",
]);
const warnings = new Map<
  string,
  Array<{ reason: string; moderator: string; date: Date }>
>();

function inferMentionCommand(question: string): string | undefined {
  const normalized = question
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
  const mentionsRoute = /\b(ruta|rutas|recorrido|recorridos)\b/.test(normalized);
  const asksHowToDoRoute =
    mentionsRoute &&
    /\b(como|hacer|hago|registrar|iniciar|participar|organizar|realizar|empezar|comenzar)\b/.test(
      normalized,
    );

  if (asksHowToDoRoute) {
    return "route-guide";
  }
  if (/\b(reportar|reporto|reporte|reportes|denunciar|denuncio|soporte)\b/.test(normalized)) {
    return "reporte";
  }
  if (/\b(sesion|sesiones|horario|horarios|hora|requisito|requisitos)\b/.test(normalized)) {
    return "sesion";
  }
  if (/\b(regla|reglas|reglamento|norma|normas|permitido|prohibido)\b/.test(normalized)) {
    return "reglas";
  }
  if (/\b(consejo|consejos|conducir|manejar|velocidad|direccionales|frenadas)\b/.test(normalized)) {
    return "consejos";
  }
  if (/\b(unidad|unidades|autobus(?:es)?|bus(?:es)?|camion(?:es)?|vehiculo(?:s)?)\b/.test(normalized)) {
    return "unidades";
  }
  if (/\b(incidente|incidentes|accidente|accidentes|falla|fallas|bloqueo|bloqueos|retraso|retrasos)\b/.test(normalized)) {
    return "incidentes";
  }
  if (mentionsRoute) {
    return "rutas";
  }
  if (/\b(info|informacion|comunidad|servidor|grupo|quienes|somos)\b/.test(normalized)) {
    return "info";
  }
  if (/\b(ayuda|comandos)\b/.test(normalized)) {
    return "ayuda";
  }

  return undefined;
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

client.once(Events.ClientReady, (readyClient) => {
  console.info(`Bot conectado como ${readyClient.user.tag} para Bus Simulator 95D.`);
  readyClient.user.setActivity("conduciendo la ruta 95D", {
    type: ActivityType.Watching,
  });
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) {
    return;
  }

  const botUserId = client.user?.id;
  const botMentioned =
    botUserId !== undefined && message.mentions.users.has(botUserId);
  const commandInput = botUserId
    ? message.content.replace(new RegExp(`<@!?${botUserId}>`, "g"), " ").trim()
    : message.content.trim();

  let command: string | undefined;

  if (botMentioned && !commandInput.startsWith(PREFIX)) {
    command = inferMentionCommand(commandInput);

    if (!command) {
      const moderatorRoleExists =
        message.guild?.roles.cache.has(MODERATOR_ROLE_ID) ?? false;
      const fallbackContent = moderatorRoleExists
        ? `Aún no tengo una respuesta para esa pregunta. <@&${MODERATOR_ROLE_ID}> ¿podrían ayudar? Esperaremos la respuesta de un moderador. Mientras tanto, puedes usar \`!ayuda\`.`
        : "Aún no tengo una respuesta para esa pregunta y no pude encontrar el rol de moderadores para avisar. Usa `!ayuda` para ver los comandos.";

      try {
        await message.reply({
          content: fallbackContent,
          allowedMentions: {
            parse: [],
            roles: moderatorRoleExists ? [MODERATOR_ROLE_ID] : [],
            repliedUser: false,
          },
        });
      } catch (error) {
        console.error("No se pudo responder a la mención del bot.", error);
      }
      return;
    }
  } else {
    if (!commandInput.startsWith(PREFIX)) {
      return;
    }

    command = commandInput
      .slice(PREFIX.length)
      .trim()
      .split(/\s+/)[0]
      ?.toLowerCase();
  }

  if (!command) {
    return;
  }

  const args = commandInput.startsWith(PREFIX)
    ? commandInput.slice(PREFIX.length).trim().split(/\s+/).slice(1)
    : [];
  const staffMember = message.member;
  const isStaff =
    staffMember?.permissions.has(PermissionFlagsBits.Administrator) === true ||
    staffMember?.roles.cache.some((role) => role.name === STAFF_ROLE) === true;

  if (ADMIN_COMMANDS.has(command)) {
    if (!message.guild || !staffMember) {
      return message.reply("Este comando solo se puede usar dentro del servidor.");
    }

    if (!isStaff) {
      return message.reply("❌ No tienes permiso para utilizar este comando.");
    }
  }

  let response: string | undefined;

  switch (command) {
    case "route-guide":
      response = [
        "¡Claro! Para realizar una ruta en la comunidad:",
        "",
        "1. Elige un recorrido disponible con `!rutas`.",
        "2. Consulta los horarios y la disponibilidad con la administración; revisa `!sesion` para conocer los requisitos.",
        "3. Sigue las indicaciones de `!reglas` y `!consejos` durante el recorrido.",
        "4. Registra tu ruta en <#1553391662196199434> y publica una fotografía en <#1553391990882959441>.",
      ].join("\n");
      break;
    case "ruta":
      response = [
        "**Ruta Oficial 95D**",
        "",
        "Terminal Central Calzada Madero",
        "→ Periférico Oriente Plaza Comercial",
        "→ Terminal Norte",
        "",
        "Duración aproximada: 35 minutos por vuelta",
        "Unidades asignadas: Volvo B8R, Irizar i6 y MAN Lion's Coach",
      ].join("\n");
      break;
    case "rutas":
      response = [
        "🚌 RUTAS DISPONIBLES",
        "BUS SIMULATOR MÉXICO-95D",
        "",
        "Consulta los recorridos disponibles dentro de nuestra comunidad.",
        "",
        "📍 SALIDAS DESDE CIUDAD DE MÉXICO",
        "🔹 Ciudad de México ➜ Chilpancingo",
        "🔹 Ciudad de México ➜ Cuernavaca",
        "",
        "📍 SALIDAS DESDE CUERNAVACA",
        "🔹 Cuernavaca ➜ Ciudad de México",
        "🔹 Cuernavaca ➜ Chilpancingo",
        "",
        "📍 SALIDAS DESDE CHILPANCINGO",
        "🔹 Chilpancingo ➜ Ciudad de México",
        "🔹 Chilpancingo ➜ Cuernavaca",
        "",
        "━━━━━━━━━━━━━━━━━━",
        "",
        "🚍 INFORMACIÓN IMPORTANTE",
        "Consulta los horarios y la disponibilidad de cada ruta con la administración.",
        "",
        "❤️ ¡Buen viaje y disfruta del recorrido!",
      ].join("\n");
      break;
    case "info":
      response = [
        "🚌 BUS SIMULATOR MÉXICO-95D",
        "",
        "¡Bienvenido a nuestra comunidad!",
        "",
        "Somos un servidor dedicado a Bus Simulator México-95D, donde los jugadores pueden convivir, compartir experiencias y mantenerse al tanto de las novedades del juego.",
        "",
        "📌 ¿QUÉ ENCONTRARÁS AQUÍ?",
        "🔹 Comunidad de jugadores.",
        "🔹 Noticias y novedades.",
        "🔹 Compartir rutas y experiencias.",
        "🔹 Eventos y actividades.",
        "🔹 Ayuda y soporte.",
        "",
        "🤝 NUESTRO OBJETIVO",
        "Crear una comunidad activa, respetuosa y divertida para todos los amantes del simulador.",
        "",
        "❤️ ¡Gracias por formar parte de nuestra comunidad!",
      ].join("\n");
      break;
    case "consejos":
      response = [
        "🚌 CONSEJOS PARA CONDUCTORES",
        "BUS SIMULATOR MÉXICO-95D",
        "",
        "¡Conduce con responsabilidad y disfruta cada recorrido!",
        "",
        "🚍 CONSEJOS DE CONDUCCIÓN",
        "🔹 Mantén una velocidad adecuada durante el trayecto.",
        "🔹 Respeta las señales de tránsito.",
        "🔹 Utiliza las direccionales antes de girar.",
        "🔹 Mantén una distancia segura con otros vehículos.",
        "🔹 Evita frenadas y movimientos bruscos.",
        "🔹 Respeta los límites de velocidad.",
        "",
        "👥 SERVICIO A PASAJEROS",
        "🔹 Realiza paradas en lugares adecuados.",
        "🔹 Mantén un embarque y desembarque realista.",
        "🔹 Espera a que los pasajeros suban y bajen antes de continuar.",
        "",
        "📋 DURANTE TUS RUTAS",
        "🔹 Registra correctamente tu recorrido.",
        "🔹 Mantén una buena conducta en el Roleplay.",
        "🔹 Respeta a los demás conductores.",
        "",
        "━━━━━━━━━━━━━━━━━━",
        "",
        "⭐ RECUERDA:",
        "Un buen conductor no es el que llega primero, sino el que realiza un recorrido seguro y responsable.",
        "",
        "❤️ ¡Disfruta de Bus Simulator México-95D!",
      ].join("\n");
      break;
    case "unidades":
      response = [
        "🚌 CATÁLOGO DE AUTOBUSES",
        "",
        "🔴 ETN",
        "• Marcopolo G8 1800 DD",
        "• Volvo 9800 2018 Euro 5",
        "• Marcopolo G8 1800 DD",
        "• Volvo 9800 DD Euro 6",
        "• Volvo 9800 DD",
        "• Marcopolo Paradiso G8 1800 DD",
        "• Volvo 9700 6x4 (Tuneado)",
        "• Marcopolo G8",
        "",
        "🟡 TURISTAR",
        "• Irizar i8 Efficient Scania Nuvak",
        "• Marcopolo G8 1800 DD",
        "• Marcopolo G8 1800 DD",
        "",
        "🔵 CRISTINA TOURS",
        "• Volvo 9700 2011",
        "",
        "🟢 TOUR EXPRESS",
        "• Volvo 9700 2011",
        "",
        "🟣 VIVELO X AUTOBUS",
        "• Volvo 9700 2011 6x8",
      ].join("\n");
      break;
    case "incidentes":
      response = [
        "🚨 INCIDENTES EN RUTA",
        "BUS SIMULATOR MÉXICO-95D",
        "",
        "Durante un recorrido pueden presentarse diferentes situaciones. Es importante mantener la calma y actuar de manera responsable.",
        "",
        "⚠️ TIPOS DE INCIDENTES",
        "🔹 Accidentes de tránsito.",
        "🔹 Fallas mecánicas del autobús.",
        "🔹 Problemas con los pasajeros.",
        "🔹 Bloqueos o cierres de carretera.",
        "🔹 Retrasos durante el recorrido.",
        "🔹 Problemas con otros conductores.",
        "",
        "🛠️ ¿QUÉ HACER ANTE UN INCIDENTE?",
        "",
        "1. Mantén la calma y evita maniobras bruscas.",
        "2. Estaciona en un lugar seguro cuando sea posible.",
        "3. Informa a la administración si afecta tu ruta.",
        "4. Respeta las reglas de Roleplay.",
        "5. Espera indicaciones si necesitas asistencia.",
        "",
        "📋 IMPORTANTE",
        "Si ocurre un incidente durante tu recorrido, informa lo sucedido y presenta evidencias cuando corresponda.",
        "",
        "━━━━━━━━━━━━━━━━━━",
        "",
        "🚍 RECUERDA: La seguridad y el buen Roleplay son responsabilidad de todos.",
        "",
        "❤️ Administración de Bus Simulator México-95D.",
      ].join("\n");
      break;
    case "reglas":
      response = [
        "🚌 REGLAMENTO OFICIAL | BUS SIMULATOR MÉXICO-95D",
        "",
        "Para mantener una comunidad organizada y un Roleplay realista, todos los miembros deberán cumplir las siguientes reglas.",
        "",
        "🚍 REGLAS DE ROLEPLAY (RP)",
        "",
        "1. Mantener una velocidad controlada durante el recorrido.",
        "2. Respetar todas las señales y reglas de tránsito.",
        "3. Utilizar correctamente las direccionales y las luces estacionarias.",
        "4. No conducir a una velocidad que no puedas controlar.",
        "5. Registrar la ruta en <#1553391662196199434> y publicar una fotografía en <#1553391990882959441>.",
        "6. No abandonar una ruta sin un motivo válido. Si necesitas retirarte rápidamente, estaciona el autobús a la orilla.",
        "7. Mantener un embarque y desembarque realista de pasajeros.",
        "",
        "📋 REGLAS GENERALES",
        "",
        "1. No insultar, provocar ni faltar al respeto a ningún miembro.",
        "2. No exigir pruebas de manera inmediata.",
        "3. No compartir enlaces sin autorización. Únicamente se permiten enlaces de videos en <#1553393421090029769>.",
        "4. Respetar a los administradores y a todos los miembros por igual.",
        "5. Está completamente prohibido el doxing y compartir información privada de otras personas.",
        "",
        "⚠️ IMPORTANTE",
        "El incumplimiento de estas reglas puede ocasionar sanciones dependiendo de la gravedad de la falta.",
        "",
        "❤️ Gracias por respetar el reglamento y ayudar a mantener una comunidad agradable para todos.",
      ].join("\n");
      break;
    case "sesion":
      response = [
        "**Próxima sesión oficial**",
        "",
        "Frecuencia: todos los días",
        `Hora: ${SESSION_TIME}`,
        `ID del servidor: ${SERVER_ID}`,
        "Requisito: tener el rol de Conductor verificado para entrar.",
      ].join("\n");
      break;
    case "reporte":
      response = [
        "**Cómo reportar un fallo**",
        "",
        "Publica en #reportes con esta información:",
        "• Tipo de fallo: mapa, unidad o servidor",
        "• Captura de pantalla, si es posible",
        "• Descripción de lo que pasó",
        "",
        "El staff revisará tu reporte lo antes posible.",
      ].join("\n");
      break;
    case "advertir": {
      const user = message.mentions.users.first();

      if (!user) {
        response = "Uso: `!advertir @usuario motivo`";
        break;
      }

      const reason = args.slice(1).join(" ").trim() || "Sin motivo especificado";
      const userWarnings = warnings.get(user.id) ?? [];
      userWarnings.push({
        reason,
        moderator: message.author.tag,
        date: new Date(),
      });
      warnings.set(user.id, userWarnings);
      response = `⚠️ ${user.tag} recibió una advertencia.\nMotivo: ${reason}`;
      break;
    }
    case "avisos": {
      const user = message.mentions.users.first();

      if (!user) {
        response = "Uso: `!avisos @usuario`";
        break;
      }

      const userWarnings = warnings.get(user.id) ?? [];
      const visibleWarnings = userWarnings.slice(-20);
      const warningLines = visibleWarnings.map(
        (warning, index) => `${index + 1}. ${warning.reason}`,
      );
      if (userWarnings.length > visibleWarnings.length) {
        warningLines.unshift(
          `Mostrando los 20 avisos más recientes de ${userWarnings.length}.`,
        );
      }

      response = [
        `📋 Advertencias de ${user.tag}: ${userWarnings.length}`,
        warningLines.join("\n") || "Sin advertencias.",
      ].join("\n");
      break;
    }
    case "limpiar": {
      if (!staffMember?.permissions.has(PermissionFlagsBits.ManageMessages)) {
        response = "❌ Te falta el permiso para gestionar mensajes.";
        break;
      }

      const amount = Number(args[0]);
      if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
        response = "Uso: `!limpiar cantidad` (1 a 100)";
        break;
      }

      if (
        !message.channel.isTextBased() ||
        !("bulkDelete" in message.channel)
      ) {
        response = "Este comando solo funciona en canales de texto.";
        break;
      }

      try {
        const deleted = await message.channel.bulkDelete(amount, true);
        await message.channel.send({
          content: `🧹 Se eliminaron ${deleted.size} mensajes.`,
          allowedMentions: { parse: [] },
        });
        return;
      } catch (error) {
        console.error("No se pudieron limpiar los mensajes.", error);
        response =
          "❌ No pude borrar los mensajes. Verifica que el bot tenga permiso para gestionar mensajes.";
      }
      break;
    }
    case "expulsar": {
      const targetMember = message.mentions.members?.first();
      const reason = args.slice(1).join(" ").trim() || "Sin motivo";

      if (!targetMember) {
        response = "Uso: `!expulsar @usuario motivo`";
        break;
      }
      if (!targetMember.kickable) {
        response = "No puedo expulsar a ese miembro.";
        break;
      }

      try {
        await targetMember.kick(reason);
        response = `👢 ${targetMember.user.tag} fue expulsado. Motivo: ${reason}`;
      } catch (error) {
        console.error("No se pudo expulsar al miembro.", error);
        response = "❌ No pude expulsar a ese miembro.";
      }
      break;
    }
    case "ban": {
      const targetMember = message.mentions.members?.first();
      const reason = args.slice(1).join(" ").trim() || "Sin motivo";

      if (!targetMember) {
        response = "Uso: `!ban @usuario motivo`";
        break;
      }
      if (!targetMember.bannable) {
        response = "No puedo bloquear a ese miembro.";
        break;
      }

      try {
        await targetMember.ban({ reason });
        response = `🔨 ${targetMember.user.tag} fue bloqueado. Motivo: ${reason}`;
      } catch (error) {
        console.error("No se pudo bloquear al miembro.", error);
        response = "❌ No pude bloquear a ese miembro.";
      }
      break;
    }
    case "desban": {
      const guild = message.guild;
      const id = args[0];

      if (!guild) {
        response = "Este comando solo se puede usar dentro del servidor.";
        break;
      }
      if (!id || !/^\d{17,20}$/.test(id)) {
        response = "Uso: `!desban ID_DEL_USUARIO`";
        break;
      }

      try {
        await guild.members.unban(id);
        response = "✅ Bloqueo retirado correctamente.";
      } catch (error) {
        console.error("No se pudo retirar el bloqueo.", error);
        response = "❌ No se pudo retirar el bloqueo.";
      }
      break;
    }
    case "silenciar": {
      const targetMember = message.mentions.members?.first();
      const minutes = Number(args[1]);

      if (
        !targetMember ||
        !Number.isInteger(minutes) ||
        minutes < 1 ||
        minutes > 40320
      ) {
        response = "Uso: `!silenciar @usuario minutos` (1 a 40320)";
        break;
      }
      if (!targetMember.moderatable) {
        response = "No puedo restringir a ese miembro.";
        break;
      }

      try {
        await targetMember.timeout(minutes * 60 * 1000, "Moderación");
        response = `🔇 ${targetMember.user.tag} fue silenciado temporalmente.`;
      } catch (error) {
        console.error("No se pudo silenciar al miembro.", error);
        response = "❌ No pude silenciar a ese miembro.";
      }
      break;
    }
    case "encuesta": {
      const question = args.join(" ").trim();

      if (!question) {
        response = "Uso: `!encuesta pregunta`";
        break;
      }

      try {
        const poll = await message.channel.send({
          embeds: [
            new EmbedBuilder()
              .setColor("#D71920")
              .setTitle("📊 ENCUESTA | ETN TURISTAR MCS")
              .setDescription(question)
              .setFooter({ text: "Participa y comparte tu opinión." }),
          ],
        });

        await poll.react("✅");
        await poll.react("❌");
        response = "✅ Encuesta publicada.";
      } catch (error) {
        console.error("No se pudo publicar la encuesta.", error);
        response =
          "❌ No pude publicar la encuesta o agregar las reacciones. Revisa los permisos del bot.";
      }
      break;
    }
    case "servidor": {
      const guild = message.guild;
      if (!guild) {
        response = "Este comando solo se puede usar dentro del servidor.";
        break;
      }

      response = [
        "🚌 ETN TURISTAR MCS",
        `👥 Miembros: ${guild.memberCount}`,
        `📅 Creado: ${guild.createdAt.toLocaleDateString("es-MX")}`,
      ].join("\n");
      break;
    }
    case "staff": {
      const guild = message.guild;
      if (!guild) {
        response = "Este comando solo se puede usar dentro del servidor.";
        break;
      }

      const role = guild.roles.cache.find(
        (guildRole) => guildRole.name === STAFF_ROLE,
      );
      if (!role) {
        response = `No encontré el rol ${STAFF_ROLE}.`;
        break;
      }

      const staffNames = role.members.map((guildMember) => guildMember.user.tag);
      const visibleStaff = staffNames.slice(0, 30);
      const remainingStaff = staffNames.length - visibleStaff.length;
      response = [
        "🛡️ Equipo administrativo:",
        visibleStaff.join("\n") || "Sin miembros.",
        remainingStaff > 0 ? `…y ${remainingStaff} más.` : "",
      ]
        .filter(Boolean)
        .join("\n");
      break;
    }
    case "anuncio":
    case "evento": {
      const guild = message.guild;
      const publicationType = command === "evento" ? "evento" : "anuncio";
      const publicationLabel = command === "evento" ? "Evento" : "Anuncio";

      if (!guild) {
        response = "Este comando solo se puede usar dentro del servidor.";
        break;
      }

      const announcementInput = message.content
        .slice(PREFIX.length + command.length)
        .trim();
      const announcementMatch = announcementInput.match(
        /^(?:<#(\d{17,20})>|(\d{17,20}))\s+([\s\S]+)$/,
      );
      const channelId = announcementMatch?.[1] ?? announcementMatch?.[2];
      const announcement = announcementMatch?.[3]?.trim();

      if (!channelId || !announcement) {
        response =
          `Uso: \`!${command} #canal mensaje\`. También puedes indicar el ID del canal.`;
        break;
      }

      if (announcement.length > 2000) {
        response = "El texto no puede superar los 2,000 caracteres.";
        break;
      }

      try {
        const destination = await guild.channels.fetch(channelId);

        if (
          !destination ||
          !destination.isTextBased() ||
          !destination.isSendable()
        ) {
          response =
            "No encontré un canal de texto válido con ese ID en este servidor.";
          break;
        }

        try {
          const announcementEmbed = new EmbedBuilder()
            .setColor("#D71920")
            .setTitle(
              command === "evento"
                ? "📅 EVENTO OFICIAL | ETN TURISTAR MCS"
                : "📢 ANUNCIO OFICIAL | ETN TURISTAR MCS",
            )
            .setDescription(announcement)
            .setTimestamp();

          await destination.send({
            embeds: [announcementEmbed],
            allowedMentions: { parse: [] },
          });
          response = `${publicationLabel} publicado en <#${destination.id}>.`;
        } catch (error) {
          console.error(`No se pudo publicar el ${publicationType}.`, error);
          response =
            `No pude publicar el ${publicationType}. Verifica que el bot pueda ver y enviar mensajes en ese canal.`;
        }
      } catch (error) {
        console.error(`No se pudo consultar el canal del ${publicationType}.`, error);
        response =
          "No pude encontrar ese canal. Usa un canal de este servidor o comprueba el ID.";
      }
      break;
    }
    case "ayuda":
      response = [
        "🚌 BUS SIMULATOR MÉXICO-95D",
        "",
        "¡Bienvenido al menú de ayuda!",
        "",
        "Aquí encontrarás los comandos disponibles para utilizar nuestro bot.",
        "",
        "📋 COMANDOS GENERALES",
        '🔹 "!ayuda" — Muestra este menú.',
        '🔹 "!info" — Información de nuestra comunidad.',
        '🔹 "!rutas" — Consulta los recorridos disponibles.',
        '🔹 "!consejos" — Consejos para conducir.',
        '🔹 "!unidades" — Consulta el catálogo de autobuses.',
        '🔹 "!incidentes" — Qué hacer ante un incidente en ruta.',
        '🔹 "!reglas" — Consulta las reglas del servidor.',
        "",
        "❤️ ¡Gracias por formar parte de nuestra comunidad!",
        "Disfruta de Bus Simulator México-95D y respeta a los demás miembros.",
      ].join("\n");
      break;
    default:
      return;
  }

  try {
    await message.reply({
      content: response,
      allowedMentions: { repliedUser: false },
    });
  } catch (error) {
    console.error("No se pudo enviar la respuesta del comando.", error);
  }
});

client.on("error", (error) => {
  console.error("Error de conexión de Discord.", error);
});

const shutdown = () => {
  client.destroy();
  process.exit(0);
};

process.once("SIGINT", shutdown);
process.once("SIGTERM", shutdown);

await client.login(token);
